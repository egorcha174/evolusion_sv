
// This file is deprecated.
// All built-in themes have been moved to src/themes/presets/*.json
// Import aggregated themes from src/themes/index.ts instead.
export {};
