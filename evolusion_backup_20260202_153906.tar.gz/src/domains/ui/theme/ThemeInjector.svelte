
<script lang="ts">
  // ThemeInjector is deprecated as theme application is handled via store subscription.
  // Kept as empty placeholder to avoid build errors if referenced.
</script>
