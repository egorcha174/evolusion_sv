
// This file is deprecated.
// Theme definitions have moved to src/themes/presets/*.json
// Global theme logic is now in src/themes/index.ts
export {};
