
// This file is deprecated. Please import from 'src/domains/ui/theme/store' instead.
// Re-exporting to prevent build errors in consumers that haven't been updated yet.
export * from '../ui/theme/store';
