# 📋 ТЕХНИЧЕСКОЕ ЗАДАНИЕ: Видеопотоки от камер в Svelte 5 дашборде

## 📦 ПОЛНЫЙ ПАКЕТ ТЗ

Это краткое резюме. Полные документы:

### **1. ts_camera_spec.md** — ГЛАВНОЕ ТЗ
- ✅ Архитектура системы
- ✅ 3 источника видео (сетевые камеры, Go2rtc, Frigate)
- ✅ Компонентная архитектура
- ✅ API endpoints
- ✅ Performance requirements
- ✅ Security requirements

### **2. svelte5_guide.md** — ПРАКТИЧЕСКИЙ ГАЙД С КОДОМ
- ✅ Quick Start
- ✅ Структура проекта
- ✅ Готовый код для Camera Store
- ✅ WebRTC Composable
- ✅ CameraCard компонент
- ✅ API endpoints
- ✅ Тестирование

### **3. README_TECH_SPEC.md** — НАВИГАЦИЯ (этот файл)
- ✅ Обзор
- ✅ Как использовать документы
- ✅ Quick reference

---

## 🎯 В ДВУХ СЛОВАХ

**Задача**: Создать Svelte 5 дашборд для видеопотоков с:
- WebRTC от Go2rtc (0.5-1 сек задержка)
- Events от Frigate (AI-детекция)
- Поддержка сетевых RTSP/MJPEG камер
- Production-ready ошибки и мониторинг

**Результат**: Working MVP за 3-4 часа, production-ready за неделю

---

## 🚀 КАК НАЧАТЬ

### 1. Прочитайте архитектуру (30 мин)
→ Откройте **ts_camera_spec.md**

### 2. Копируйте код (3-4 часа)
→ Откройте **svelte5_guide.md**

### 3. Тестируйте
→ Следуйте инструкциям в гайде

---

## 📂 ВСЕ ФАЙЛЫ

**Основные:**
- `ts_camera_spec.md` — ТЗ (1100 строк)
- `svelte5_guide.md` — Практика (974 строки)
- `README_TECH_SPEC.md` — Навигация (этот файл)

**Дополнительно (если нужно):**
- `ha_camera_research.md` — Исследование CORS
- `ha_camera_guide.md` — Примеры кода
- `ha_camera_summary.md` — Резюме

---

## ✅ QUICK REFERENCE

| Что вам нужно | Файл | Раздел |
|--------------|------|--------|
| Понять архитектуру | ts_camera_spec.md | АРХИТЕКТУРА СИСТЕМЫ |
| Создать Store | svelte5_guide.md | STEP 1 |
| Создать WebRTC | svelte5_guide.md | STEP 2 |
| Создать компонент | svelte5_guide.md | STEP 3 |
| Создать страницу | svelte5_guide.md | STEP 4 |
| API endpoint | svelte5_guide.md | STEP 5 |
| Конфигурация | svelte5_guide.md | STEP 6 |
| Запустить | svelte5_guide.md | ЗАПУСК И ТЕСТИРОВАНИЕ |

---

## 💡 HELP

- **WebSocket ошибки?** → svelte5_guide.md → Troubleshooting
- **Как работает WebRTC?** → ts_camera_spec.md → Источники данных
- **Где го2rtc?** → ts_camera_spec.md → Go2rtc Streaming Proxy
- **Как конфигурировать?** → svelte5_guide.md → STEP 6

---

**Все готово! Начните с ts_camera_spec.md 🚀**
